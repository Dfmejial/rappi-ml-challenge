from pkg_resources import resource_filename
filepath = resource_filename(__name__, '/raw_data')