# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['app',
 'app.conf',
 'app.data',
 'app.model',
 'app.tests',
 'app.tests.data',
 'app.tests.model']

package_data = \
{'': ['*'], 'app.data': ['raw_data/*'], 'app.model': ['trained_models/*']}

install_requires = \
['joblib>=1.1.0,<2.0.0',
 'numpy>=1.18.5,<2.0.0',
 'pandas>=1.1.5,<2.0.0',
 'scikit-learn>=1.2.1',
 'seaborn>=0.13.0,<0.14.0']

entry_points = \
{'console_scripts': ['rappi-dfmejial = app.main:main']}

setup_kwargs = {
    'name': 'app',
    'version': '0.0.1',
    'description': 'Rappi Titanic challenge',
    'long_description': None,
    'author': 'Daniel Mejia',
    'author_email': 'dfmejial@unal.edu.co',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<3.10',
}


setup(**setup_kwargs)
