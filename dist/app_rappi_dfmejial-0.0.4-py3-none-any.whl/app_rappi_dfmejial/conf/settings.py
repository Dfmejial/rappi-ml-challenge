COLS_TO_REMOVE = ["PassengerId", "Name", "Ticket", "Cabin"]

TRAINING_FEATURES = ["Pclass", "Sex", "Age", "SibSp", "Parch", "Fare", "Embarked"]

TRUE_VALUE = "Survived"